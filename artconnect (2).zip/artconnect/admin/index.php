?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_admin();

$page_title = 'Admin Dashboard';

// Get statistics
$stats = [
    'total_users' => 0,
    'total_artists' => 0,
    'total_events' => 0,
    'total_artworks' => 0,
    'pending_comments' => 0
];

try {
    // Total users
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $stats['total_users'] = $stmt->fetchColumn();
   
    // Total artists
    $stmt = $pdo->query("SELECT COUNT(*) FROM artist_profiles");
    $stats['total_artists'] = $stmt->fetchColumn();
   
    // Total events
    $stmt = $pdo->query("SELECT COUNT(*) FROM events");
    $stats['total_events'] = $stmt->fetchColumn();
   
    // Total artworks
    $stmt = $pdo->query("SELECT COUNT(*) FROM artworks");
    $stats['total_artworks'] = $stmt->fetchColumn();
   
    // Pending comments
    $stmt = $pdo->query("SELECT COUNT(*) FROM comments WHERE is_approved = 0");
    $stats['pending_comments'] = $stmt->fetchColumn();
   
} catch (PDOException $e) {
    set_flash_message('Error loading dashboard statistics.', 'danger');
}

// Get recent events
$recent_events = [];
try {
    $stmt = $pdo->prepare("
        SELECT e.*, u.username as creator_name
        FROM events e
        JOIN users u ON e.created_by = u.id
        ORDER BY e.created_at DESC
        LIMIT 5
    ");
    $stmt->execute();
    $recent_events = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('Error loading recent events.', 'danger');
}

// Get recent users
$recent_users = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
    $stmt->execute();
    $recent_users = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('Error loading recent users.', 'danger');
}

include '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="h2 mb-3">
            <i class="fas fa-tachometer-alt me-2"></i>Admin Dashboard
        </h1>
        <p class="text-muted">Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! Here's what's happening with ArtConnect Winnipeg.</p>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-5">
    <div class="col-md-6 col-lg-4 mb-3">
        <div class="card dashboard-stats text-center">
            <div class="card-body">
                <i class="fas fa-users fa-3x mb-3 opacity-75"></i>
                <h3 class="display-6 fw-bold"><?php echo number_format($stats['total_users']); ?></h3>
                <p class="mb-0">Total Users</p>
            </div>
        </div>
    </div>
   
    <div class="col-md-6 col-lg-4 mb-3">
        <div class="card dashboard-stats text-center">
            <div class="card-body">
                <i class="fas fa-paint-brush fa-3x mb-3 opacity-75"></i>
                <h3 class="display-6 fw-bold"><?php echo number_format($stats['total_artists']); ?></h3>
                <p class="mb-0">Artists</p>
            </div>
        </div>
    </div>
   
    <div class="col-md-6 col-lg-4 mb-3">
        <div class="card dashboard-stats text-center">
            <div class="card-body">
                <i class="fas fa-calendar fa-3x mb-3 opacity-75"></i>
                <h3 class="display-6 fw-bold"><?php echo number_format($stats['total_events']); ?></h3>
                <p class="mb-0">Events</p>
            </div>
        </div>
    </div>
   
    <div class="col-md-6 col-lg-4 mb-3">
        <div class="card dashboard-stats text-center">
            <div class="card-body">
                <i class="fas fa-image fa-3x mb-3 opacity-75"></i>
                <h3 class="display-6 fw-bold"><?php echo number_format($stats['total_artworks']); ?></h3>
                <p class="mb-0">Artworks</p>
            </div>
        </div>
    </div>
   
    <div class="col-md-6 col-lg-4 mb-3">
        <div class="card dashboard-stats text-center">
            <div class="card-body">
                <i class="fas fa-comments fa-3x mb-3 opacity-75"></i>
                <h3 class="display-6 fw-bold"><?php echo number_format($stats['pending_comments']); ?></h3>
                <p class="mb-0">Pending Comments</p>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mb-5">
    <div class="col-12">
        <h3 class="h4 mb-3">Quick Actions</h3>
        <div class="row">
            <div class="col-md-6 col-lg-3 mb-3">
                <a href="manage_users.php" class="btn btn-outline-primary w-100 py-3">
                    <i class="fas fa-users fa-2x d-block mb-2"></i>
                    Manage Users
                </a>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
                <a href="manage_events.php" class="btn btn-outline-primary w-100 py-3">
                    <i class="fas fa-calendar-plus fa-2x d-block mb-2"></i>
                    Manage Events
                </a>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
                <a href="manage_comments.php" class="btn btn-outline-primary w-100 py-3">
                    <i class="fas fa-comments fa-2x d-block mb-2"></i>
                    Moderate Comments
                    <?php if ($stats['pending_comments'] > 0): ?>
                        <span class="badge bg-danger ms-2"><?php echo $stats['pending_comments']; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
                <a href="manage_categories.php" class="btn btn-outline-primary w-100 py-3">
                    <i class="fas fa-tags fa-2x d-block mb-2"></i>
                    Event Categories
                </a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Recent Events -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="fas fa-calendar me-2"></i>Recent Events
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_events)): ?>
                    <p class="text-muted mb-0">No events created yet.</p>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($recent_events as $event): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($event['title']); ?></h6>
                                    <p class="mb-1 text-muted small">
                                        <i class="fas fa-calendar me-1"></i>
                                        <?php echo format_datetime($event['event_date']); ?>
                                    </p>
                                    <small class="text-muted">
                                        Created by <?php echo htmlspecialchars($event['creator_name']); ?>
                                    </small>
                                </div>
                                <a href="manage_events.php?edit=<?php echo $event['id']; ?>"
                                   class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="text-center mt-3">
                        <a href="manage_events.php" class="btn btn-primary btn-sm">View All Events</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
   
    <!-- Recent Users -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="fas fa-users me-2"></i>Recent Users
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_users)): ?>
                    <p class="text-muted mb-0">No users registered yet.</p>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($recent_users as $user): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($user['username']); ?></h6>
                                    <p class="mb-1 text-muted small"><?php echo htmlspecialchars($user['email']); ?></p>
                                    <small class="text-muted">
                                        <span class="badge bg-secondary"><?php echo ucfirst($user['role']); ?></span>
                                        Joined <?php echo format_date($user['created_at']); ?>
                                    </small>
                                </div>
                                <a href="manage_users.php?edit=<?php echo $user['id']; ?>"
                                   class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="text-center mt-3">
                        <a href="manage_users.php" class="btn btn-primary btn-sm">View All Users</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- System Information -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>System Information
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <dl class="row">
                            <dt class="col-sm-4">PHP Version:</dt>
                            <dd class="col-sm-8"><?php echo PHP_VERSION; ?></dd>
                           
                            <dt class="col-sm-4">Server Software:</dt>
                            <dd class="col-sm-8"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></dd>
                           
                            <dt class="col-sm-4">Database:</dt>
                            <dd class="col-sm-8">MySQL <?php echo $pdo->getAttribute(PDO::ATTR_SERVER_VERSION); ?></dd>
                        </dl>
                    </div>
                    <div class="col-md-6">
                        <dl class="row">
                            <dt class="col-sm-4">Upload Directory:</dt>
                            <dd class="col-sm-8">
                                <?php
                                $upload_dir = '../uploads';
                                echo is_writable($upload_dir) ?
                                    '<span class="text-success">Writable</span>' :
                                    '<span class="text-danger">Not Writable</span>';
                                ?>
                            </dd>
                           
                            <dt class="col-sm-4">Sessions:</dt>
                            <dd class="col-sm-8">
                                <?php echo ini_get('session.save_handler'); ?>
                            </dd>
                           
                            <dt class="col-sm-4">Last Updated:</dt>
                            <dd class="col-sm-8"><?php echo date('Y-m-d H:i:s'); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

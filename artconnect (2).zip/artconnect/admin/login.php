<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    if (is_admin()) {
        header('Location: index.php');
    } elseif (is_artist()) {
        header('Location: ../artist/dashboard.php');
    } else {
        header('Location: ../index.php');
    }
    exit();
}

$error_message = '';
$show_register = false;

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        $username = sanitize_input($_POST['username']);
        $password = $_POST['password'];
       
        if (empty($username) || empty($password)) {
            $error_message = 'Please enter both username and password.';
        } else {
            // Check user credentials
            $stmt = $pdo->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
           
            if ($user && password_verify($password, $user['password'])) {
                // Login successful
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
               
                set_flash_message('Welcome back, ' . $user['username'] . '!', 'success');
               
                // Redirect based on role
                if ($user['role'] === 'admin') {
                    header('Location: index.php');
                } elseif ($user['role'] === 'artist') {
                    header('Location: ../artist/dashboard.php');
                } else {
                    header('Location: ../index.php');
                }
                exit();
            } else {
                $error_message = 'Invalid username or password.';
            }
        }
    } elseif (isset($_POST['register'])) {
        // Handle registration
        $username = sanitize_input($_POST['reg_username']);
        $email = sanitize_input($_POST['reg_email']);
        $password = $_POST['reg_password'];
        $confirm_password = $_POST['reg_confirm_password'];
        $role = sanitize_input($_POST['reg_role']);
       
        // Validation
        if (empty($username) || empty($email) || empty($password)) {
            $error_message = 'All fields are required.';
        } elseif (!is_valid_email($email)) {
            $error_message = 'Please enter a valid email address.';
        } elseif ($password !== $confirm_password) {
            $error_message = 'Passwords do not match.';
        } elseif (strlen($password) < 6) {
            $error_message = 'Password must be at least 6 characters long.';
        } else {
            // Check if username or email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
           
            if ($stmt->fetch()) {
                $error_message = 'Username or email already exists.';
            } else {
                // Create new user
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
               
                if ($stmt->execute([$username, $email, $hashed_password, $role])) {
                    $user_id = $pdo->lastInsertId();
                   
                    // Auto-login after registration
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['username'] = $username;
                    $_SESSION['role'] = $role;
                   
                    set_flash_message('Registration successful! Welcome to ArtConnect Winnipeg.', 'success');
                   
                    // Redirect based on role
                    if ($role === 'admin') {
                        header('Location: index.php');
                    } elseif ($role === 'artist') {
                        header('Location: ../artist/dashboard.php');
                    } else {
                        header('Location: ../index.php');
                    }
                    exit();
                } else {
                    $error_message = 'Registration failed. Please try again.';
                }
            }
        }
        $show_register = true;
    }
}

if (isset($_GET['register'])) {
    $show_register = true;
}

$page_title = $show_register ? 'Register' : 'Login';
include '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-primary text-white text-center py-4">
                <h3 class="mb-0">
                    <i class="fas fa-paint-brush me-2"></i>
                    <?php echo $show_register ? 'Join' : 'Welcome to'; ?> ArtConnect
                </h3>
            </div>
            <div class="card-body p-5">
                <?php if ($error_message): ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <?php if (!$show_register): ?>
                    <!-- Login Form -->
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="username" class="form-label">
                                <i class="fas fa-user me-2"></i>Username
                            </label>
                            <input type="text" class="form-control" id="username" name="username"
                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                                   required>
                        </div>
                       
                        <div class="mb-4">
                            <label for="password" class="form-label">
                                <i class="fas fa-lock me-2"></i>Password
                            </label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                       
                        <button type="submit" name="login" class="btn btn-primary w-100 mb-3">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </button>
                    </form>
                   
                    <hr>
                    <div class="text-center">
                        <p class="mb-0">Don't have an account?</p>
                        <a href="?register=1" class="btn btn-outline-primary">
                            <i class="fas fa-user-plus me-2"></i>Create Account
                        </a>
                    </div>
                   
                    <!-- Demo Credentials -->
                    <div class="mt-4 p-3 bg-light rounded">
                        <h6 class="text-primary">Demo Credentials:</h6>
                        <small class="text-muted">
                            <strong>Admin:</strong> admin / admin123<br>
                            <strong>Artist:</strong> artist1 / admin123
                        </small>
                    </div>
                   
                <?php else: ?>
                    <!-- Registration Form -->
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="reg_username" class="form-label">
                                <i class="fas fa-user me-2"></i>Username
                            </label>
                            <input type="text" class="form-control" id="reg_username" name="reg_username"
                                   value="<?php echo isset($_POST['reg_username']) ? htmlspecialchars($_POST['reg_username']) : ''; ?>"
                                   required>
                        </div>
                       
                        <div class="mb-3">
                            <label for="reg_email" class="form-label">
                                <i class="fas fa-envelope me-2"></i>Email
                            </label>
                            <input type="email" class="form-control" id="reg_email" name="reg_email"
                                   value="<?php echo isset($_POST['reg_email']) ? htmlspecialchars($_POST['reg_email']) : ''; ?>"
                                   required>
                        </div>
                       
                        <div class="mb-3">
                            <label for="reg_role" class="form-label">
                                <i class="fas fa-users me-2"></i>Account Type
                            </label>
                            <select class="form-control" id="reg_role" name="reg_role" required>
                                <option value="">Select account type...</option>
                                <option value="public" <?php echo (isset($_POST['reg_role']) && $_POST['reg_role'] === 'public') ? 'selected' : ''; ?>>
                                    Public User (Browse and comment)
                                </option>
                                <option value="artist" <?php echo (isset($_POST['reg_role']) && $_POST['reg_role'] === 'artist') ? 'selected' : ''; ?>>
                                    Artist (Create portfolio)
                                </option>
                            </select>
                        </div>
                       
                        <div class="mb-3">
                            <label for="reg_password" class="form-label">
                                <i class="fas fa-lock me-2"></i>Password
                            </label>
                            <input type="password" class="form-control" id="reg_password" name="reg_password"
                                   minlength="6" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                       
                        <div class="mb-4">
                            <label for="reg_confirm_password" class="form-label">
                                <i class="fas fa-lock me-2"></i>Confirm Password
                            </label>
                            <input type="password" class="form-control" id="reg_confirm_password"
                                   name="reg_confirm_password" required>
                        </div>
                       
                        <button type="submit" name="register" class="btn btn-primary w-100 mb-3">
                            <i class="fas fa-user-plus me-2"></i>Create Account
                        </button>
                    </form>
                   
                    <hr>
                    <div class="text-center">
                        <p class="mb-0">Already have an account?</p>
                        <a href="login.php" class="btn btn-outline-primary">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.querySelector('form[method="POST"]');
    if (registerForm && registerForm.querySelector('input[name="reg_password"]')) {
        const password = registerForm.querySelector('input[name="reg_password"]');
        const confirmPassword = registerForm.querySelector('input[name="reg_confirm_password"]');
       
        function validatePasswords() {
            if (password.value !== confirmPassword.value) {
                confirmPassword.setCustomValidity('Passwords do not match');
            } else {
                confirmPassword.setCustomValidity('');
            }
        }
       
        password.addEventListener('input', validatePasswords);
        confirmPassword.addEventListener('input', validatePasswords);
    }
});
</script>

<?php include '../includes/footer.php'; ?>

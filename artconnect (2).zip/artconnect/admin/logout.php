<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Clear all session data
$_SESSION = array();

// Destroy the session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-42000, '/');
}

// Destroy the session
session_destroy();

// Set a flash message for the next session
session_start();
set_flash_message('You have been successfully logged out.', 'success');

// Redirect to home page
header('Location: ../index.php');
exit();
?>

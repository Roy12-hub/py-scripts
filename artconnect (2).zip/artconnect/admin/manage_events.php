<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_admin();

$page_title = 'Manage Events';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_event'])) {
        $title = sanitize_input($_POST['title']);
        $description = sanitize_input($_POST['description']);
        $event_date = $_POST['event_date'];
        $location = sanitize_input($_POST['location']);
        $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $max_attendees = !empty($_POST['max_attendees']) ? (int)$_POST['max_attendees'] : null;
       
        if (empty($title) || empty($description) || empty($event_date) || empty($location)) {
            set_flash_message('Title, description, date, and location are required.', 'danger');
        } else {
            $slug = create_slug($title);
            $image_path = null;
           
            // Handle image upload
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $upload_result = upload_image($_FILES['image'], '../uploads/events');
                if ($upload_result['success']) {
                    $image_path = $upload_result['filename'];
                } else {
                    set_flash_message($upload_result['error'], 'danger');
                }
            }
           
            if (!isset($upload_result) || $upload_result['success']) {
                $stmt = $pdo->prepare("
                    INSERT INTO events (title, description, event_date, location, category_id, created_by, image_path, max_attendees, slug)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
               
                if ($stmt->execute([$title, $description, $event_date, $location, $category_id, $_SESSION['user_id'], $image_path, $max_attendees, $slug])) {
                    set_flash_message('Event created successfully.', 'success');
                } else {
                    set_flash_message('Failed to create event.', 'danger');
                    if ($image_path) {
                        delete_image($image_path, '../uploads/events');
                    }
                }
            }
        }
    }
   
    if (isset($_POST['update_event'])) {
        $event_id = (int)$_POST['event_id'];
        $title = sanitize_input($_POST['title']);
        $description = sanitize_input($_POST['description']);
        $event_date = $_POST['event_date'];
        $location = sanitize_input($_POST['location']);
        $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $max_attendees = !empty($_POST['max_attendees']) ? (int)$_POST['max_attendees'] : null;
       
        if (empty($title) || empty($description) || empty($event_date) || empty($location)) {
            set_flash_message('Title, description, date, and location are required.', 'danger');
        } else {
            $slug = create_slug($title);
           
            // Get current event for image handling
            $stmt = $pdo->prepare("SELECT image_path FROM events WHERE id = ?");
            $stmt->execute([$event_id]);
            $current_event = $stmt->fetch();
            $image_path = $current_event['image_path'];
           
            // Handle image upload
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $upload_result = upload_image($_FILES['image'], '../uploads/events');
                if ($upload_result['success']) {
                    // Delete old image
                    if ($image_path) {
                        delete_image($image_path, '../uploads/events');
                    }
                    $image_path = $upload_result['filename'];
                } else {
                    set_flash_message($upload_result['error'], 'danger');
                }
            }
           
            // Handle image removal
            if (isset($_POST['remove_image']) && $image_path) {
                delete_image($image_path, '../uploads/events');
                $image_path = null;
            }
           
            if (!isset($upload_result) || $upload_result['success']) {
                $stmt = $pdo->prepare("
                    UPDATE events
                    SET title = ?, description = ?, event_date = ?, location = ?, category_id = ?,
                        image_path = ?, max_attendees = ?, slug = ?
                    WHERE id = ?
                ");
               
                if ($stmt->execute([$title, $description, $event_date, $location, $category_id, $image_path, $max_attendees, $slug, $event_id])) {
                    set_flash_message('Event updated successfully.', 'success');
                } else {
                    set_flash_message('Failed to update event.', 'danger');
                }
            }
        }
    }
   
    if (isset($_POST['delete_event'])) {
        $event_id = (int)$_POST['event_id'];
       
        // Get event image for deletion
        $stmt = $pdo->prepare("SELECT image_path FROM events WHERE id = ?");
        $stmt->execute([$event_id]);
        $event = $stmt->fetch();
       
        $stmt = $pdo->prepare("DELETE FROM events WHERE id = ?");
        if ($stmt->execute([$event_id])) {
            // Delete image file
            if ($event && $event['image_path']) {
                delete_image($event['image_path'], '../uploads/events');
            }
            set_flash_message('Event deleted successfully.', 'success');
        } else {
            set_flash_message('Failed to delete event.', 'danger');
        }
    }
}

// Get event for editing
$edit_event = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_event = $stmt->fetch();
}

// Get categories for dropdown
$stmt = $pdo->query("SELECT * FROM event_categories ORDER BY name");
$categories = $stmt->fetchAll();

// Pagination and filtering
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : 0;

$where_conditions = [];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(title LIKE ? OR description LIKE ? OR location LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($category_filter > 0) {
    $where_conditions[] = "category_id = ?";
    $params[] = $category_filter;
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count
$count_sql = "SELECT COUNT(*) FROM events $where_clause";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_events = $count_stmt->fetchColumn();

// Get events
$sql = "
    SELECT e.*, ec.name as category_name, u.username as creator_name
    FROM events e
    LEFT JOIN event_categories ec ON e.category_id = ec.id
    JOIN users u ON e.created_by = u.id
    $where_clause
    ORDER BY e.event_date DESC
    LIMIT ? OFFSET ?
";
$params[] = $per_page;
$params[] = $offset;
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

$pagination = paginate($total_events, $per_page, $page);

include '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="h2 mb-3">
            <i class="fas fa-calendar me-2"></i>Manage Events
        </h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active">Manage Events</li>
            </ol>
        </nav>
    </div>
</div>

<!-- Search and Filters -->
<div class="row mb-4">
    <div class="col-md-8">
        <form method="GET" class="row g-3">
            <div class="col-md-6">
                <input type="text" name="search" class="form-control"
                       placeholder="Search events..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-4">
                <select name="category" class="form-control">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>"
                                <?php echo $category_filter == $category['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-outline-primary w-100">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>
    </div>
    <div class="col-md-4 text-end">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createEventModal">
            <i class="fas fa-plus me-2"></i>Create Event
        </button>
    </div>
</div>

<!-- Events Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            Events (<?php echo number_format($total_events); ?>)
            <?php if (!empty($search) || $category_filter > 0): ?>
                - Filtered
            <?php endif; ?>
        </h5>
    </div>
    <div class="card-body p-0">
        <?php if (empty($events)): ?>
            <div class="text-center py-5">
                <i class="fas fa-calendar fa-3x text-muted mb-3"></i>
                <p class="text-muted">No events found.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Event</th>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Category</th>
                            <th>Creator</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($events as $event): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php if ($event['image_path']): ?>
                                            <img src="../uploads/events/<?php echo htmlspecialchars($event['image_path']); ?>"
                                                 class="rounded me-3" width="50" height="50" style="object-fit: cover;"
                                                 alt="<?php echo htmlspecialchars($event['title']); ?>">
                                        <?php else: ?>
                                            <div class="bg-secondary rounded me-3 d-flex align-items-center justify-content-center"
                                                 style="width: 50px; height: 50px;">
                                                <i class="fas fa-calendar text-white"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div>
                                            <strong><?php echo htmlspecialchars($event['title']); ?></strong>
                                            <br><small class="text-muted"><?php echo truncate_text($event['description'], 60); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php echo format_datetime($event['event_date']); ?>
                                    <?php if (strtotime($event['event_date']) < time()): ?>
                                        <br><small class="text-muted">(Past)</small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($event['location']); ?></td>
                                <td>
                                    <?php if ($event['category_name']): ?>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($event['category_name']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">Uncategorized</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($event['creator_name']); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="../public/event_detail.php?id=<?php echo $event['id']; ?>"
                                           class="btn btn-sm btn-outline-info" target="_blank">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="?edit=<?php echo $event['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-outline-danger"
                                                onclick="confirmDelete(<?php echo $event['id']; ?>, '<?php echo htmlspecialchars($event['title']); ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Pagination -->
<?php if ($pagination['total_pages'] > 1): ?>
    <nav aria-label="Events pagination" class="mt-4">
        <ul class="pagination">
            <?php if ($pagination['has_prev']): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $pagination['prev_page']; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>">
                        Previous
                    </a>
                </li>
            <?php endif; ?>
           
            <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                <li class="page-item <?php echo $i === $pagination['current_page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
            <?php endfor; ?>
           
            <?php if ($pagination['has_next']): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $pagination['next_page']; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>">
                        Next
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>

<!-- Create Event Modal -->
<div class="modal fade" id="createEventModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Event</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title" class="form-label">Event Title</label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="category_id" class="form-label">Category</label>
                                <select class="form-control" id="category_id" name="category_id">
                                    <option value="">Select category...</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>">
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="event_date" class="form-label">Event Date & Time</label>
                                <input type="datetime-local" class="form-control" id="event_date" name="event_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="max_attendees" class="form-label">Max Attendees (optional)</label>
                                <input type="number" class="form-control" id="max_attendees" name="max_attendees" min="1">
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location" required>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Event Image (optional)</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        <small class="text-muted">Max file size: 5MB. Supported formats: JPG, PNG, GIF</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="create_event" class="btn btn-primary">Create Event</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Event Modal -->
<?php if ($edit_event): ?>
<div class="modal fade show" id="editEventModal" tabindex="-1" style="display: block;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="event_id" value="<?php echo $edit_event['id']; ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Event: <?php echo htmlspecialchars($edit_event['title']); ?></h5>
                    <a href="manage_events.php" class="btn-close"></a>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_title" class="form-label">Event Title</label>
                                <input type="text" class="form-control" id="edit_title" name="title"
                                       value="<?php echo htmlspecialchars($edit_event['title']); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_category_id" class="form-label">Category</label>
                                <select class="form-control" id="edit_category_id" name="category_id">
                                    <option value="">Select category...</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>"
                                                <?php echo $category['id'] == $edit_event['category_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="4" required><?php echo htmlspecialchars($edit_event['description']); ?></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_event_date" class="form-label">Event Date & Time</label>
                                <input type="datetime-local" class="form-control" id="edit_event_date" name="event_date"
                                       value="<?php echo date('Y-m-d\TH:i', strtotime($edit_event['event_date'])); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_max_attendees" class="form-label">Max Attendees (optional)</label>
                                <input type="number" class="form-control" id="edit_max_attendees" name="max_attendees"
                                       value="<?php echo $edit_event['max_attendees']; ?>" min="1">
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="edit_location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="edit_location" name="location"
                               value="<?php echo htmlspecialchars($edit_event['location']); ?>" required>
                    </div>
                   
                    <?php if ($edit_event['image_path']): ?>
                        <div class="mb-3">
                            <label class="form-label">Current Image</label>
                            <div class="d-flex align-items-center">
                                <img src="../uploads/events/<?php echo htmlspecialchars($edit_event['image_path']); ?>"
                                     class="rounded me-3" width="100" height="100" style="object-fit: cover;">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="remove_image" name="remove_image">
                                    <label class="form-check-label" for="remove_image">
                                        Remove current image
                                    </label>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                   
                    <div class="mb-3">
                        <label for="edit_image" class="form-label">
                            <?php echo $edit_event['image_path'] ? 'Replace Image' : 'Add Image'; ?> (optional)
                        </label>
                        <input type="file" class="form-control" id="edit_image" name="image" accept="image/*">
                        <small class="text-muted">Max file size: 5MB. Supported formats: JPG, PNG, GIF</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="manage_events.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" name="update_event" class="btn btn-primary">Update Event</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var editModal = new bootstrap.Modal(document.getElementById('editEventModal'));
    editModal.show();
});
</script>
<?php endif; ?>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="deleteForm">
                <input type="hidden" name="event_id" id="deleteEventId">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the event <strong id="deleteEventTitle"></strong>?</p>
                    <p class="text-danger">This action cannot be undone and will remove all associated comments and RSVPs.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_event" class="btn btn-danger">Delete Event</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function confirmDelete(eventId, eventTitle) {
    document.getElementById('deleteEventId').value = eventId;
    document.getElementById('deleteEventTitle').textContent = eventTitle;
    var deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
    deleteModal.show();
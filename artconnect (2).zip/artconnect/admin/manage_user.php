<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_admin();

$page_title = 'Manage Users';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_user'])) {
        $username = sanitize_input($_POST['username']);
        $email = sanitize_input($_POST['email']);
        $password = $_POST['password'];
        $role = sanitize_input($_POST['role']);
        
        if (empty($username) || empty($email) || empty($password) || empty($role)) {
            set_flash_message('All fields are required.', 'danger');
        } elseif (!is_valid_email($email)) {
            set_flash_message('Please enter a valid email address.', 'danger');
        } else {
            // Check if username or email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->fetch()) {
                set_flash_message('Username or email already exists.', 'danger');
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
                
                if ($stmt->execute([$username, $email, $hashed_password, $role])) {
                    set_flash_message('User created successfully.', 'success');
                } else {
                    set_flash_message('Failed to create user.', 'danger');
                }
            }
        }
    }
    
    if (isset($_POST['update_user'])) {
        $user_id = (int)$_POST['user_id'];
        $username = sanitize_input($_POST['username']);
        $email = sanitize_input($_POST['email']);
        $role = sanitize_input($_POST['role']);
        $new_password = $_POST['new_password'];
        
        if (empty($username) || empty($email) || empty($role)) {
            set_flash_message('Username, email, and role are required.', 'danger');
        } elseif (!is_valid_email($email)) {
            set_flash_message('Please enter a valid email address.', 'danger');
        } else {
            // Check if username or email already exists for other users
            $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->execute([$username, $email, $user_id]);
            
            if ($stmt->fetch()) {
                set_flash_message('Username or email already exists for another user.', 'danger');
            } else {
                if (!empty($new_password)) {
                    // Update with new password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ?, role = ? WHERE id = ?");
                    $result = $stmt->execute([$username, $email, $hashed_password, $role, $user_id]);
                } else {
                    // Update without changing password
                    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
                    $result = $stmt->execute([$username, $email, $role, $user_id]);
                }
                
                if ($result) {
                    set_flash_message('User updated successfully.', 'success');
                } else {
                    set_flash_message('Failed to update user.', 'danger');
                }
            }
        }
    }
    
    if (isset($_POST['delete_user'])) {
        $user_id = (int)$_POST['user_id'];
        
        // Don't allow deleting yourself
        if ($user_id == $_SESSION['user_id']) {
            set_flash_message('You cannot delete your own account.', 'danger');
        } else {
            try {
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                if ($stmt->execute([$user_id])) {
                    set_flash_message('User deleted successfully.', 'success');
                } else {
                    set_flash_message('Failed to delete user.', 'danger');
                }
            } catch (PDOException $e) {
                set_flash_message('Cannot delete user - they may have associated data.', 'danger');
            }
        }
    }
}


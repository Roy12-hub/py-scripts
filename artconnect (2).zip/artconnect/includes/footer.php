</div>
    </main>

    <footer class="bg-dark text-light mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="fas fa-palette me-2"></i>ArtConnect Winnipeg</h5>
                    <p class="mb-0">Connecting local artists with the community through art exhibitions, workshops, and collaborative events.</p>
                </div>
                <div class="col-md-3">
                    <h6>Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="/artconnect/" class="text-light text-decoration-none">Home</a></li>
                        <li><a href="/artconnect/public/artists.php" class="text-light text-decoration-none">Artists</a></li>
                        <li><a href="/artconnect/public/events.php" class="text-light text-decoration-none">Events</a></li>
                        <li><a href="/artconnect/public/search.php" class="text-light text-decoration-none">Search</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h6>Contact</h6>
                    <p class="mb-1"><i class="fas fa-envelope me-2"></i>info@artconnect.ca</p>
                    <p class="mb-1"><i class="fas fa-phone me-2"></i>(204) 555-0123</p>
                    <p class="mb-0"><i class="fas fa-map-marker-alt me-2"></i>Winnipeg, MB</p>
                </div>
            </div>
            <hr class="my-3">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> ArtConnect Winnipeg. Built with ❤️ for the local art community.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="/artconnect/js/main.js"></script>
</body>
</html>

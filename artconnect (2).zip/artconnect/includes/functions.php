<?php
// Helper functions for ArtConnect Winnipeg CMS

// Sanitize input data
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Validate email format
function is_valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Check if user is logged in
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Check if user is artist
function is_artist() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'artist';
}

// Redirect to login page if not authenticated
function require_login() {
    if (!is_logged_in()) {
        header('Location: /artconnect/admin/login.php');
        exit();
    }
}

// Require admin privileges
function require_admin() {
    require_login();
    if (!is_admin()) {
        header('Location: /artconnect/index.php');
        exit();
    }
}

// Generate a slug from title
function create_slug($text) {
    // Convert to lowercase
    $text = strtolower($text);
    // Replace spaces with hyphens
    $text = preg_replace('/\s+/', '-', $text);
    // Remove special characters except hyphens
    $text = preg_replace('/[^a-z0-9\-]/', '', $text);
    // Remove multiple consecutive hyphens
    $text = preg_replace('/-+/', '-', $text);
    // Remove hyphens from beginning and end
    $text = trim($text, '-');
    return $text;
}

// Format date for display
function format_date($date) {
    return date('F j, Y', strtotime($date));
}

// Format datetime for display
function format_datetime($datetime) {
    return date('F j, Y g:i A', strtotime($datetime));
}

// Check if uploaded file is an image
function is_image($file) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $file_info = getimagesize($file['tmp_name']);
   
    if ($file_info === false) {
        return false;
    }
   
    return in_array($file_info['mime'], $allowed_types);
}

// Upload image file
function upload_image($file, $upload_dir, $max_size = 5242880) { // 5MB default
    // Check if upload directory exists, create if not
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
   
    // Check file size
    if ($file['size'] > $max_size) {
        return ['success' => false, 'error' => 'File too large. Maximum size is 5MB.'];
    }
   
    // Check if file is an image
    if (!is_image($file)) {
        return ['success' => false, 'error' => 'File is not a valid image.'];
    }
   
    // Generate unique filename
    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . $file_extension;
    $target_path = $upload_dir . '/' . $filename;
   
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return ['success' => true, 'filename' => $filename];
    } else {
        return ['success' => false, 'error' => 'Failed to upload file.'];
    }
}

// Delete uploaded file
function delete_image($filename, $upload_dir) {
    $file_path = $upload_dir . '/' . $filename;
    if (file_exists($file_path)) {
        return unlink($file_path);
    }
    return true;
}

// Paginate results
function paginate($total_records, $records_per_page, $current_page) {
    $total_pages = ceil($total_records / $records_per_page);
    $offset = ($current_page - 1) * $records_per_page;
   
    return [
        'total_pages' => $total_pages,
        'current_page' => $current_page,
        'offset' => $offset,
        'has_prev' => $current_page > 1,
        'has_next' => $current_page < $total_pages,
        'prev_page' => $current_page - 1,
        'next_page' => $current_page + 1
    ];
}

// Display flash messages
function display_flash_message() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        echo "<div class='alert alert-{$type} alert-dismissible fade show' role='alert'>
                {$message}
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
              </div>";
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
    }
}

// Set flash message
function set_flash_message($message, $type = 'info') {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
}

// Validate CSRF token (basic implementation)
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Get user's full information
function get_user_info($user_id, $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

// Get artist profile by user ID
function get_artist_profile($user_id, $pdo) {
    $stmt = $pdo->prepare("SELECT ap.*, u.username, u.email FROM artist_profiles ap
                          JOIN users u ON ap.user_id = u.id WHERE ap.user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

// Truncate text for excerpts
function truncate_text($text, $length = 150) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}
?>

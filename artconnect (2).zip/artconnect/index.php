<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$page_title = 'Home';

// Fetch recent events
$stmt = $pdo->prepare("
    SELECT e.*, ec.name as category_name
    FROM events e
    LEFT JOIN event_categories ec ON e.category_id = ec.id
    WHERE e.event_date >= NOW()
    ORDER BY e.event_date ASC
    LIMIT 3
");
$stmt->execute();
$upcoming_events = $stmt->fetchAll();

// Fetch featured artists (artists with recent artworks)
$stmt = $pdo->prepare("
    SELECT ap.*, u.username, COUNT(aw.id) as artwork_count
    FROM artist_profiles ap
    JOIN users u ON ap.user_id = u.id
    LEFT JOIN artworks aw ON ap.id = aw.artist_id
    GROUP BY ap.id
    HAVING artwork_count > 0
    ORDER BY ap.updated_at DESC
    LIMIT 4
");
$stmt->execute();
$featured_artists = $stmt->fetchAll();

include 'includes/header.php';
?>

<!-- Hero Section -->
<div class="hero-section bg-primary text-white py-5 mb-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-4 fw-bold mb-3">Welcome to ArtConnect Winnipeg</h1>
                <p class="lead mb-4">Discover local artists, explore their portfolios, and join our vibrant community events. Connect with Winnipeg's creative spirit!</p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="public/artists.php" class="btn btn-light btn-lg">
                        <i class="fas fa-palette me-2"></i>Browse Artists
                    </a>
                    <a href="public/events.php" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-calendar me-2"></i>View Events
                    </a>
                </div>
            </div>
            <div class="col-lg-4 text-center">
                <i class="fas fa-paint-brush display-1 opacity-50"></i>
            </div>
        </div>
    </div>
</div>

<!-- Featured Artists Section -->
<section class="mb-5">
    <div class="row">
        <div class="col-12">
            <h2 class="text-center mb-4">Featured Artists</h2>
            <?php if (empty($featured_artists)): ?>
                <div class="text-center text-muted">
                    <p>No featured artists available at the moment. Check back soon!</p>
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($featured_artists as $artist): ?>
                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body text-center">
                                    <?php if ($artist['profile_image']): ?>
                                        <img src="uploads/profiles/<?php echo htmlspecialchars($artist['profile_image']); ?>"
                                             class="rounded-circle mb-3" width="80" height="80"
                                             style="object-fit: cover;" alt="<?php echo htmlspecialchars($artist['display_name']); ?>">
                                    <?php else: ?>
                                        <div class="bg-secondary rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                             style="width: 80px; height: 80px;">
                                            <i class="fas fa-user fa-2x text-white"></i>
                                        </div>
                                    <?php endif; ?>
                                   
                                    <h5 class="card-title"><?php echo htmlspecialchars($artist['display_name']); ?></h5>
                                    <p class="text-muted small"><?php echo htmlspecialchars($artist['art_style'] ?? 'Mixed Media'); ?></p>
                                    <p class="card-text"><?php echo truncate_text($artist['bio'] ?? 'Local Winnipeg artist', 80); ?></p>
                                    <span class="badge bg-primary"><?php echo $artist['artwork_count']; ?> Artworks</span>
                                </div>
                                <div class="card-footer bg-transparent">
                                    <a href="public/artist_profile.php?id=<?php echo $artist['id']; ?>"
                                       class="btn btn-outline-primary btn-sm w-100">View Portfolio</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="text-center">
                    <a href="public/artists.php" class="btn btn-primary">View All Artists</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Upcoming Events Section -->
<section class="mb-5">
    <div class="row">
        <div class="col-12">
            <h2 class="text-center mb-4">Upcoming Events</h2>
            <?php if (empty($upcoming_events)): ?>
                <div class="text-center text-muted">
                    <p>No upcoming events scheduled. Stay tuned for exciting announcements!</p>
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($upcoming_events as $event): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm">
                                <?php if ($event['image_path']): ?>
                                    <img src="uploads/events/<?php echo htmlspecialchars($event['image_path']); ?>"
                                         class="card-img-top" style="height: 200px; object-fit: cover;"
                                         alt="<?php echo htmlspecialchars($event['title']); ?>">
                                <?php endif; ?>
                               
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                                    <p class="card-text"><?php echo truncate_text($event['description'], 100); ?></p>
                                   
                                    <div class="event-details">
                                        <p class="mb-2">
                                            <i class="fas fa-calendar text-primary me-2"></i>
                                            <?php echo format_datetime($event['event_date']); ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-map-marker-alt text-primary me-2"></i>
                                            <?php echo htmlspecialchars($event['location']); ?>
                                        </p>
                                        <?php if ($event['category_name']): ?>
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($event['category_name']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-footer bg-transparent">
                                    <a href="public/event_detail.php?id=<?php echo $event['id']; ?>"
                                       class="btn btn-primary btn-sm w-100">Learn More</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="text-center">
                    <a href="public/events.php" class="btn btn-primary">View All Events</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Call to Action Section -->
<section class="bg-light py-5 mb-5">
    <div class="row text-center">
        <div class="col-12">
            <h2 class="mb-4">Join Our Community</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="feature-box">
                        <i class="fas fa-users fa-3x text-primary mb-3"></i>
                        <h4>Connect</h4>
                        <p>Meet fellow artists and art enthusiasts in Winnipeg's vibrant creative community.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-box">
                        <i class="fas fa-lightbulb fa-3x text-primary mb-3"></i>
                        <h4>Create</h4>
                        <p>Showcase your artwork and share your creative journey with a supportive audience.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-box">
                        <i class="fas fa-star fa-3x text-primary mb-3"></i>
                        <h4>Inspire</h4>
                        <p>Discover new perspectives and be inspired by the diverse artistic talents in our city.</p>
                    </div>
                </div>
            </div>
            <?php if (!is_logged_in()): ?>
                <a href="admin/login.php" class="btn btn-primary btn-lg mt-3">
                    <i class="fas fa-sign-in-alt me-2"></i>Join ArtConnect Today
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

ArtConnect Winnipeg - Main JavaScript File

document.addEventListener('DOMContentLoaded', function() {
   
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Image preview for file uploads
    const fileInputs = document.querySelectorAll('input[type="file"][accept*="image"]');
    fileInputs.forEach(function(input) {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    // Create or update preview
                    let preview = input.parentNode.querySelector('.image-preview');
                    if (!preview) {
                        preview = document.createElement('div');
                        preview.className = 'image-preview mt-2';
                        input.parentNode.appendChild(preview);
                    }
                    preview.innerHTML = `
                        <img src="${e.target.result}" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                        <button type="button" class="btn btn-sm btn-outline-danger ms-2" onclick="clearFileInput(this)">
                            <i class="fas fa-times"></i> Remove
                        </button>
                    `;
                };
                reader.readAsDataURL(file);
            }
        });
    });

    // Form validation enhancements
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Dynamic search functionality
    const searchInputs = document.querySelectorAll('.dynamic-search');
    searchInputs.forEach(function(input) {
        let timeout;
        input.addEventListener('input', function(e) {
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                if (e.target.value.length >= 3 || e.target.value.length === 0) {
                    // Trigger search after 500ms delay
                    performDynamicSearch(e.target);
                }
            }, 500);
        });
    });

    // Smooth scrolling for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Character counter for textareas
    const textareas = document.querySelectorAll('textarea[data-max-length]');
    textareas.forEach(function(textarea) {
        const maxLength = parseInt(textarea.getAttribute('data-max-length'));
        const counter = document.createElement('small');
        counter.className = 'form-text text-muted character-counter';
        textarea.parentNode.appendChild(counter);
       
        function updateCounter() {
            const remaining = maxLength - textarea.value.length;
            counter.textContent = `${remaining} characters remaining`;
            counter.className = `form-text ${remaining < 0 ? 'text-danger' : 'text-muted'} character-counter`;
        }
       
        textarea.addEventListener('input', updateCounter);
        updateCounter();
    });

    // Auto-resize textareas
    const autoResizeTextareas = document.querySelectorAll('.auto-resize');
    autoResizeTextareas.forEach(function(textarea) {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
       
        // Initial resize
        textarea.style.height = 'auto';
        textarea.style.height = (textarea.scrollHeight) + 'px';
    });

    // Loading states for buttons
    const loadingButtons = document.querySelectorAll('.btn-loading');
    loadingButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const originalText = button.innerHTML;
            button.innerHTML = '<span class="loading me-2"></span>Loading...';
            button.disabled = true;
           
            // Re-enable after form submission or timeout
            setTimeout(function() {
                button.innerHTML = originalText;
                button.disabled = false;
            }, 3000);
        });
    });

    // Confirmation dialogs
    const confirmButtons = document.querySelectorAll('[data-confirm]');
    confirmButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm');
            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        });
    });

    // RSVP functionality
    const rsvpForms = document.querySelectorAll('.rsvp-form');
    rsvpForms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            submitRSVP(form);
        });
    });

    // Comment form enhancements
    const commentForms = document.querySelectorAll('.comment-form');
    commentForms.forEach(function(form) {
        const textarea = form.querySelector('textarea');
        if (textarea) {
            textarea.addEventListener('input', function() {
                const submitBtn = form.querySelector('button[type="submit"]');
                submitBtn.disabled = this.value.trim().length === 0;
            });
        }
    });

});

// Clear file input function
function clearFileInput(button) {
    const preview = button.parentNode;
    const input = preview.parentNode.querySelector('input[type="file"]');
    input.value = '';
    preview.remove();
}

// Dynamic search function
function performDynamicSearch(input) {
    // This would typically make an AJAX call to search endpoint
    console.log('Searching for:', input.value);
}

// RSVP submission function
function submitRSVP(form) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
   
    submitBtn.innerHTML = '<span class="loading me-2"></span>Submitting...';
    submitBtn.disabled = true;
   
    // Simulate AJAX submission (replace with actual implementation)
    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('RSVP submitted successfully!', 'success');
            // Update UI to reflect RSVP status
            updateRSVPStatus(data.status);
        } else {
            showAlert(data.message || 'Failed to submit RSVP. Please try again.', 'danger');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('An error occurred. Please try again.', 'danger');
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
}

// Show alert function
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container') || document.querySelector('.container');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
   
    alertContainer.insertBefore(alert, alertContainer.firstChild);
   
    // Auto-hide after 5 seconds
    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(alert);
        bsAlert.close();
    }, 5000);
}

// Update RSVP status in UI
function updateRSVPStatus(status) {
    const rsvpBadge = document.querySelector('.rsvp-status-badge');
    if (rsvpBadge) {
        rsvpBadge.className = `badge bg-${status === 'attending' ? 'success' : status === 'maybe' ? 'warning' : 'secondary'} rsvp-status-badge`;
        rsvpBadge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    }
}

// Image lazy loading
function setupLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// Call lazy loading setup if supported
if ('IntersectionObserver' in window) {
    setupLazyLoading();
}

// Masonry layout for artwork galleries
function initializeMasonry() {
    const galleries = document.querySelectorAll('.masonry-gallery');
    galleries.forEach(gallery => {
        // Simple column-based layout (can be enhanced with libraries like Masonry.js)
        const items = gallery.querySelectorAll('.masonry-item');
        items.forEach((item, index) => {
            item.style.animationDelay = `${index * 0.1}s`;
            item.classList.add('fade-in-up');
        });
    });
}

// Initialize masonry on page load
document.addEventListener('DOMContentLoaded', initializeMasonry);

// Utility functions
const utils = {
    // Format numbers with commas
    formatNumber: function(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },
   
    // Debounce function
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
   
    // Check if element is in viewport
    isInViewport: function(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
};

// Export utils for use in other scripts
window.ArtConnectUtils = utils;

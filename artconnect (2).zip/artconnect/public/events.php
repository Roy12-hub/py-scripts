<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

$page_title = 'Events';

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 6;
$offset = ($page - 1) * $per_page;

// Filtering
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$time_filter = isset($_GET['time']) ? sanitize_input($_GET['time']) : 'upcoming';

// Build WHERE clause
$where_conditions = [];
$params = [];

// Time filter
if ($time_filter === 'upcoming') {
    $where_conditions[] = "e.event_date >= NOW()";
} elseif ($time_filter === 'past') {
    $where_conditions[] = "e.event_date < NOW()";
}

// Category filter
if ($category_filter > 0) {
    $where_conditions[] = "e.category_id = ?";
    $params[] = $category_filter;
}

// Search filter
if (!empty($search)) {
    $where_conditions[] = "(e.title LIKE ? OR e.description LIKE ? OR e.location LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count
$count_sql = "SELECT COUNT(*) FROM events e $where_clause";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_events = $count_stmt->fetchColumn();

// Get events
$sql = "
    SELECT e.*, ec.name as category_name,
           (SELECT COUNT(*) FROM rsvps r WHERE r.event_id = e.id AND r.response = 'attending') as attending_count
    FROM events e
    LEFT JOIN event_categories ec ON e.category_id = ec.id
    $where_clause
    ORDER BY e.event_date " . ($time_filter === 'past' ? 'DESC' : 'ASC') . "
    LIMIT ? OFFSET ?
";
$params[] = $per_page;
$params[] = $offset;
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

// Get categories for filter dropdown
$stmt = $pdo->query("SELECT * FROM event_categories ORDER BY name");
$categories = $stmt->fetchAll();

$pagination = paginate($total_events, $per_page, $page);

include '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="h2 mb-3">
            <i class="fas fa-calendar me-2"></i>Community Events
        </h1>
        <p class="text-muted">Discover and join our exciting art events, workshops, and community gatherings in Winnipeg.</p>
    </div>
</div>

<!-- Filters -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label for="search" class="form-label">Search Events</label>
                        <input type="text" class="form-control" id="search" name="search"
                               placeholder="Keywords..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-control" id="category" name="category">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>"
                                        <?php echo $category_filter == $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="time" class="form-label">Time Period</label>
                        <select class="form-control" id="time" name="time">
                            <option value="upcoming" <?php echo $time_filter === 'upcoming' ? 'selected' : ''; ?>>Upcoming Events</option>
                            <option value="past" <?php echo $time_filter === 'past' ? 'selected' : ''; ?>>Past Events</option>
                            <option value="all" <?php echo $time_filter === 'all' ? 'selected' : ''; ?>>All Events</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-2"></i>Filter Events
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Events Grid -->
<?php if (empty($events)): ?>
    <div class="text-center py-5">
        <i class="fas fa-calendar fa-4x text-muted mb-4"></i>
        <h3 class="text-muted">No Events Found</h3>
        <p class="text-muted">
            <?php if (!empty($search) || $category_filter > 0): ?>
                Try adjusting your search criteria or browse all events.
            <?php else: ?>
                Check back soon for upcoming events and workshops!
            <?php endif; ?>
        </p>
        <?php if (!empty($search) || $category_filter > 0): ?>
            <a href="events.php" class="btn btn-primary">
                <i class="fas fa-refresh me-2"></i>Show All Events
            </a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="row">
        <?php foreach ($events as $event): ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100 event-card">
                    <?php if ($event['image_path']): ?>
                        <img src="../uploads/events/<?php echo htmlspecialchars($event['image_path']); ?>"
                             class="card-img-top" style="height: 200px; object-fit: cover;"
                             alt="<?php echo htmlspecialchars($event['title']); ?>">
                    <?php else: ?>
                        <div class="card-img-top bg-gradient-primary d-flex align-items-center justify-content-center"
                             style="height: 200px;">
                            <i class="fas fa-calendar fa-4x text-white opacity-50"></i>
                        </div>
                    <?php endif; ?>
                   
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                            <?php if ($event['category_name']): ?>
                                <span class="badge bg-primary"><?php echo htmlspecialchars($event['category_name']); ?></span>
                            <?php endif; ?>
                        </div>
                       
                        <p class="card-text flex-grow-1"><?php echo truncate_text($event['description'], 120); ?></p>
                       
                        <div class="event-details mb-3">
                            <p class="mb-2">
                                <i class="fas fa-calendar text-primary me-2"></i>
                                <strong><?php echo format_datetime($event['event_date']); ?></strong>
                                <?php if (strtotime($event['event_date']) < time()): ?>
                                    <span class="badge bg-secondary ms-2">Past</span>
                                <?php endif; ?>
                            </p>
                            <p class="mb-2">
                                <i class="fas fa-map-marker-alt text-primary me-2"></i>
                                <?php echo htmlspecialchars($event['location']); ?>
                            </p>
                            <p class="mb-0">
                                <i class="fas fa-users text-primary me-2"></i>
                                <?php echo $event['attending_count']; ?> attending
                                <?php if ($event['max_attendees']): ?>
                                    / <?php echo $event['max_attendees']; ?> max
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                   
                    <div class="card-footer bg-transparent">
                        <a href="event_detail.php?id=<?php echo $event['id']; ?>"
                           class="btn btn-primary w-100">
                            <i class="fas fa-info-circle me-2"></i>View Details & RSVP
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Pagination -->
<?php if ($pagination['total_pages'] > 1): ?>
    <nav aria-label="Events pagination" class="mt-5">
        <ul class="pagination justify-content-center">
            <?php if ($pagination['has_prev']): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $pagination['prev_page']; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>&time=<?php echo $time_filter; ?>">
                        <i class="fas fa-chevron-left me-1"></i>Previous
                    </a>
                </li>
            <?php endif; ?>
           
            <?php
            $start_page = max(1, $pagination['current_page'] - 2);
            $end_page = min($pagination['total_pages'], $pagination['current_page'] + 2);
            ?>
           
            <?php if ($start_page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=1&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>&time=<?php echo $time_filter; ?>">1</a>
                </li>
                <?php if ($start_page > 2): ?>
                    <li class="page-item disabled"><span class="page-link">...</span></li>
                <?php endif; ?>
            <?php endif; ?>
           
            <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                <li class="page-item <?php echo $i === $pagination['current_page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>&time=<?php echo $time_filter; ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
            <?php endfor; ?>
           
            <?php if ($end_page < $pagination['total_pages']): ?>
                <?php if ($end_page < $pagination['total_pages'] - 1): ?>
                    <li class="page-item disabled"><span class="page-link">...</span></li>
                <?php endif; ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $pagination['total_pages']; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>&time=<?php echo $time_filter; ?>">
                        <?php echo $pagination['total_pages']; ?>
                    </a>
                </li>
            <?php endif; ?>
           
            <?php if ($pagination['has_next']): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $pagination['next_page']; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category_filter; ?>&time=<?php echo $time_filter; ?>">
                        Next<i class="fas fa-chevron-right ms-1"></i>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
   
    <div class="text-center text-muted mt-3">
        <small>
            Showing <?php echo (($page - 1) * $per_page) + 1; ?> to
            <?php echo min($page * $per_page, $total_events); ?> of
            <?php echo number_format($total_events); ?> events
        </small>
    </div>
<?php endif; ?>

<!-- Call to Action for Artists -->
<?php if (is_logged_in() && is_artist()): ?>
    <div class="alert alert-info mt-5" role="alert">
        <div class="d-flex align-items-center">
            <i class="fas fa-lightbulb fa-2x me-3"></i>
            <div>
                <h5 class="alert-heading mb-1">Want to Host an Event?</h5>
                <p class="mb-0">Contact our admin team to propose your own workshop, exhibition, or community event!</p>
            </div>
        </div>
    </div>
<?php elseif (!is_logged_in()): ?>
    <div class="alert alert-primary mt-5" role="alert">
        <div class="d-flex align-items-center">
            <i class="fas fa-user-plus fa-2x me-3"></i>
            <div>
                <h5 class="alert-heading mb-1">Join Our Community!</h5>
                <p class="mb-2">Create an account to RSVP for events, comment, and connect with other art enthusiasts.</p>
                <a href="../admin/login.php?register=1" class="btn btn-light btn-sm">
                    <i class="fas fa-sign-in-alt me-2"></i>Sign Up Now
                </a>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
